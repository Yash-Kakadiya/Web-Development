import './App.css';
import React from "react";
import Layout from './Components/Layout';

function App() {
  return (
    <div className="App">
      <Layout />
    </div>
  );
}
export default App;

// class App extends React.Component {
//   render() {
//     return (
//       <div className="App">
//         <header className="App-header">
//           <img src={logo} className="App-logo" alt="logo" />
//           <h1>Hello from class component.😉</h1>
//         </header>

//       </div>
//     );
//   }
// }