let AboutUs=()=>{
    return(
        <>
        <h1>AboutUs Page</h1>
        </>
    )
}

export default AboutUs;