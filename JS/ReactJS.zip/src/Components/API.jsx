import React from 'react'

export default function API() {
    fetch('https://dog.ceo/api/breeds/image/random').then().then()

    return (
        <></>
    )
}
