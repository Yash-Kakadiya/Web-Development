// 3. Create a webapp in NodeJS which reads ƒles like about.txt, contact.txt and display it using http core module


const fs = require('fs');


//write
fs.writeFile('about.txt', 'about : Yash Kakadiya', (err) => {
    if (err) {
        console.log(err);
    }
});

fs.writeFile('contact.txt', 'contact : 0123456789', (err) => {
    if (err) {
        console.log(err);
    }
});

//server

const http = require('node:http');

const server = http.createServer((req, res) => {
    console.log('server created');
    console.log(req.url);
    if (req.url == '/contact') {
        fs.readFile('abc.txt', (err, data) => {
            console.log(data);
            res.end(data);
        });
    } else if (req.url == '/about') {
        fs.readFile('abc.txt', (err, data) => {
            console.log(data);
            res.end(data);
        });
    } else {
        res.end('hello');
    }
});

const port = 7000;

server.listen(port, () => {
    console.log('server listening');
});

