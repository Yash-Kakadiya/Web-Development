// 5. Demonstrate the ‘for of’ loop

// for (element of collection) {
    //      //do something
    //  }

    console.log("for of loop");
    let fruits = ["Mango", "Apple", "Papaya"];

    console.log(fruits);
    
    for (i of fruits) {
        console.log(i);
    }