// 10. Write JavaScript that handles following mouse event

class demo {
    n;
    name;

    constructor(n, name) {
        this.n = n;
        this.name = name;
    }
}

let obj = new demo(1, 'Yash');
console.log(obj.n);
console.log(obj.name);