function validateForm(e) {
    e.preventDefault();
    validateUser();
}

let error = document.querySelector(".errorMsg");

function validateUser(e) {
    let user = document.querySelector("#username").value;
    error.innerHTML = "";
    if (user === "") {
        console.log("user if ok");
        error.innerHTML = "Enter Username";
        console.log(error.innerHTML);
        return;
    } else if (user.length < 8) {
        error.innerHTML = "Invalid Username";
        return;
    }
    console.log("Username :" + user);
    validatePassword();
}

function validatePassword(e) {
    let pass = document.querySelector("#password").value;
    error.innerHTML = "";
    if (pass === "") {
        error.innerHTML = "Enter Password";
        return;
    }
    else if ((pass.length < 8 || pass.length > 12)) {
        error.innerHTML += "Invalid Password";
        return;
    }
    console.log("Password : " + pass);
}

let isPasswordHidden = true;
function showPassword(e) {
    let pass = document.querySelector("#password");
    if (isPasswordHidden) {
        pass.setAttribute('type', 'text');
        isPasswordHidden = false;
    } else {
        pass.setAttribute('type', 'password');
        isPasswordHidden = true;
    }
    // hide(pass);
}