function LogIn() {
    return (
        <div className="LogIn">
            <form>
                <h2><u>Login form</u></h2>
                <input type="text" size="30" placeholder="Username" id="inp"></input>
                <input type="password" size="30" placeholder="Password"></input>
                <button type="submit">Submit</button>
                <br />
                <Demo count='10' />
            </form>
        </div>
    );
}

function Demo(props) {
    let str = "";
    for (let i = 0; i < props.count; i++) {
        str += "¥";
    }
    return (<h1>{str}</h1>);
}

export default LogIn;