import logo from './logo.svg';
import './App.css';
import React from "react";

import { Link, Outlet } from 'react-router-dom';
import Home from './Home';
import AboutUs from './AboutUs';
import Contact from './Contact';
import LogIn from './LogIn';

function App() {
  return (
    <div className="App">
      <Layout />
      <Outlet />
    </div>
  );
}

function Layout() {
  return (
    <>
      <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item me-3">
                <Link to='/home' element={<Home />}>Home</Link>
              </li>
              <li class="nav-item me-3">
                <Link to='/about' element={<AboutUs />}>About Us</Link>
              </li>
              <li class="nav-item me-3">
                <Link to='/contact' element={<Contact />}>Contact</Link>
              </li>
              <li class="nav-item me-3">
                <Link to='/login' element={<LogIn />}>Login</Link>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <h1>Hello.🙃</h1>
      </header>


    </>
  )
}

export default App;

// class App extends React.Component {
//   render() {
//     return (
//       <div className="App">
//         <header className="App-header">
//           <img src={logo} className="App-logo" alt="logo" />
//           <h1>Hello from class component.😉</h1>
//         </header>

//       </div>
//     );
//   }
// }