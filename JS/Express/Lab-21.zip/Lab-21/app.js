const express = require('express');
const app = express();
const port = 3000;

const mongoose = require('mongoose');
const Student = require('./Student');



mongoose.connect('mongodb+srv://yashkakadiya931:yashkakadiya931@cluster0.welde.mongodb.net/students')
    .then(() => {
        console.log("Database connected");

        app.get("/students", async (req, res) => {
            const data = await Student.find();
            console.log(data);
            res.send(data)

        });
        app.get("/students/:id", async (req, res) => {
            const data = await Student.findOne({ rollno: req.params.id });
            console.log(data);
            res.send(data)

        })

        app.use(express.json());
        app.post("/", async (req, res) => {
            const { data } = req.body;
            await Student.create(data);
            console.log(data);
            res.send(data);
        });

        app.listen(port, () => {
            console.log(`server listening on port ${port}...`);
        })
    });